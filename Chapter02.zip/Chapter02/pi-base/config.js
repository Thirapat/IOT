module.exports = {
    mqtt: {
        host: '10.2.192.141',
        clientId: 'rPI_3',
        port: 8883
    }
};
